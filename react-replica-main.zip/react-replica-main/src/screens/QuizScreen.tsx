import { useState } from "react";

interface QuizScreenProps {
  onFinish: () => void;
  onQuit: () => void;
}

const questions = [
  {
    id: 1,
    text: "The permanent maxillary first molar has how many roots?",
    options: ["Two roots", "Three roots", "Four roots", "One root"],
    correct: 1,
    difficulty: "EASY",
  },
  {
    id: 2,
    text: "Which alloy is most commonly used for cast metal restorations?",
    options: ["Cobalt-chromium", "Gold alloys", "Nickel-titanium", "Stainless steel"],
    correct: 1,
    difficulty: "MEDIUM",
  },
  {
    id: 3,
    text: "The cusp of Carabelli is found on which tooth?",
    options: [
      "Mandibular first molar",
      "Maxillary second molar",
      "Maxillary first molar",
      "Mandibular second molar",
    ],
    correct: 2,
    difficulty: "MEDIUM",
  },
];

const optionLabels = ["A", "B", "C", "D"];

const QuizScreen = ({ onFinish, onQuit }: QuizScreenProps) => {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<Record<number, number>>({});

  const q = questions[currentQ];
  const total = questions.length;

  return (
    <div className="flex min-h-screen flex-col bg-background p-4">
      {/* Top Bar */}
      <div className="mb-4 flex items-center gap-3 border-b border-border pb-3">
        <button onClick={onQuit} className="text-lg text-muted-foreground">
          ✕
        </button>
        <div className="flex-1">
          <div className="text-center text-xs font-bold text-foreground">
            {currentQ + 1} / {total}
          </div>
          <div className="mt-1 h-1 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-all"
              style={{ width: `${((currentQ + 1) / total) * 100}%` }}
            />
          </div>
        </div>
        <div className="rounded-md border border-border bg-muted px-3 py-1 text-sm font-extrabold text-foreground">
          08:42
        </div>
      </div>

      {/* Question Card */}
      <div className="mb-4 rounded-xl border border-border bg-secondary p-4">
        <div className="mb-2 flex items-center gap-2">
          <span className="text-xs font-extrabold text-accent">
            Q{currentQ + 1}
          </span>
          <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] text-muted-foreground">
            {q.difficulty}
          </span>
        </div>
        <p className="text-sm font-semibold leading-relaxed text-foreground">
          {q.text}
        </p>
      </div>

      {/* Options */}
      <div className="space-y-2.5">
        {q.options.map((opt, i) => {
          const isSelected = selected[currentQ] === i;
          return (
            <button
              key={i}
              onClick={() => setSelected({ ...selected, [currentQ]: i })}
              className={`flex w-full items-center gap-3 rounded-lg border p-3.5 transition-colors ${
                isSelected
                  ? "border-accent/60 bg-accent/[0.07]"
                  : "border-border bg-secondary"
              }`}
            >
              <div
                className={`flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md border text-xs font-bold ${
                  isSelected
                    ? "border-accent bg-accent text-accent-foreground"
                    : "border-border bg-muted text-muted-foreground"
                }`}
              >
                {optionLabels[i]}
              </div>
              <span
                className={`text-left text-sm ${
                  isSelected ? "text-foreground" : "text-muted-foreground"
                }`}
              >
                {opt}
              </span>
            </button>
          );
        })}
      </div>

      {/* Navigation */}
      <div className="mt-auto flex gap-2.5 pt-6">
        <button
          onClick={() => setCurrentQ(Math.max(0, currentQ - 1))}
          disabled={currentQ === 0}
          className="flex-1 rounded-lg border border-border bg-secondary py-3 text-sm font-semibold text-muted-foreground disabled:opacity-40"
        >
          ← Prev
        </button>
        <button
          onClick={() => {
            if (currentQ < total - 1) {
              setCurrentQ(currentQ + 1);
            } else {
              onFinish();
            }
          }}
          className="flex-[2] rounded-lg bg-gradient-to-r from-primary to-accent py-3 text-sm font-bold text-primary-foreground"
        >
          {currentQ < total - 1 ? "Next →" : "Finish Quiz"}
        </button>
      </div>
    </div>
  );
};

export default QuizScreen;
