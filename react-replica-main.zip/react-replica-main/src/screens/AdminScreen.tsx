const AdminScreen = () => {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <div className="border-b border-border bg-gradient-to-br from-destructive/20 to-primary/10 p-4">
        <h2 className="text-lg font-bold text-foreground">⚙️ Admin Panel</h2>
        <p className="mt-1 text-xs text-muted-foreground">Dr. Anchal's Classes</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {/* Stats */}
        <div className="mb-4 flex gap-2.5">
          {[
            { val: "12", icon: "❓", label: "Questions", color: "text-accent" },
            { val: "5", icon: "📝", label: "Quizzes", color: "text-primary" },
            { val: "5", icon: "🎓", label: "Students", color: "text-success" },
          ].map((s) => (
            <div key={s.label} className="flex-1 rounded-lg bg-muted p-3 text-center">
              <div className={`text-2xl font-extrabold ${s.color}`}>{s.val}</div>
              <div className="mt-1 text-[10px] text-muted-foreground">
                {s.icon} {s.label}
              </div>
            </div>
          ))}
        </div>

        {/* Actions Grid */}
        <div className="mb-4 grid grid-cols-2 gap-2.5">
          {[
            { icon: "➕", label: "Add Question", border: "border-accent/25", bg: "bg-accent/[0.08]" },
            { icon: "📋", label: "Create Quiz", border: "border-primary/25", bg: "bg-primary/[0.08]" },
            { icon: "🔓", label: "Manage Access", border: "border-success/25", bg: "bg-success/[0.08]" },
            { icon: "📊", label: "View Results", border: "border-warning/25", bg: "bg-warning/[0.08]" },
          ].map((a) => (
            <button
              key={a.label}
              className={`rounded-xl border p-4 text-center ${a.border} ${a.bg}`}
            >
              <div className="mb-2 text-2xl">{a.icon}</div>
              <div className="text-xs font-semibold text-foreground">{a.label}</div>
            </button>
          ))}
        </div>

        {/* Quiz Status */}
        <div className="mb-2 text-xs font-bold text-foreground">Quiz Status</div>
        <div className="space-y-0">
          {[
            { icon: "🏆", title: "NEET MDS Mock Test 1", open: true },
            { icon: "🦷", title: "Oral Anatomy Ch. 1", open: true },
            { icon: "🔬", title: "Oral Pathology", open: false },
          ].map((q) => (
            <div
              key={q.title}
              className="flex items-center gap-3 border-b border-border py-3"
            >
              <span className="text-xl">{q.icon}</span>
              <span className="flex-1 text-sm font-semibold text-foreground">
                {q.title}
              </span>
              <span
                className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                  q.open
                    ? "bg-success/15 text-success"
                    : "bg-destructive/15 text-destructive"
                }`}
              >
                {q.open ? "✓ Open" : "🔒 Locked"}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Admin Tab Bar */}
      <div className="flex border-t border-border bg-secondary">
        <div className="flex flex-1 flex-col items-center justify-center gap-1 py-3">
          <span className="text-lg">⚙️</span>
          <span className="text-xs font-semibold text-destructive">Dashboard</span>
        </div>
      </div>
    </div>
  );
};

export default AdminScreen;
