const AnalyticsScreen = () => {
  return (
    <div className="flex-1 overflow-y-auto p-4">
      <h2 className="mb-4 text-lg font-bold text-foreground">📊 My Analytics</h2>

      {/* Stats Grid */}
      <div className="mb-2 flex gap-2.5">
        <div className="flex-1 rounded-lg bg-muted p-3 text-center">
          <div className="text-2xl font-extrabold text-accent">3</div>
          <div className="mt-1 text-[10px] text-muted-foreground">Tests Taken</div>
        </div>
        <div className="flex-1 rounded-lg bg-muted p-3 text-center">
          <div className="text-2xl font-extrabold text-primary">78%</div>
          <div className="mt-1 text-[10px] text-muted-foreground">Avg Score</div>
        </div>
      </div>
      <div className="mb-4 flex gap-2.5">
        <div className="flex-1 rounded-lg bg-muted p-3 text-center">
          <div className="text-2xl font-extrabold text-success">100%</div>
          <div className="mt-1 text-[10px] text-muted-foreground">Best Score</div>
        </div>
        <div className="flex-1 rounded-lg bg-muted p-3 text-center">
          <div className="text-2xl font-extrabold text-warning">12m</div>
          <div className="mt-1 text-[10px] text-muted-foreground">Time Spent</div>
        </div>
      </div>

      {/* Chart Section */}
      <div className="rounded-xl border border-border bg-secondary p-4">
        <div className="mb-3 text-xs font-bold text-foreground">Score Trend</div>
        <div className="flex items-end gap-3" style={{ height: 100 }}>
          {[
            { label: "Oral\nAnat", height: 50 },
            { label: "Dental\nMat", height: 75 },
            { label: "NEET\nMDS", height: 60 },
          ].map((bar) => (
            <div key={bar.label} className="flex flex-1 flex-col items-center justify-end">
              <div
                className="w-full rounded-t-md bg-gradient-to-b from-primary to-accent"
                style={{ height: bar.height }}
              />
              <span className="mt-2 whitespace-pre-line text-center text-[9px] text-muted-foreground">
                {bar.label}
              </span>
            </div>
          ))}
        </div>

        {/* Subject Performance */}
        <div className="mt-5 mb-2 text-xs font-bold text-foreground">
          Subject Performance
        </div>
        {[
          { name: "Oral Anatomy", pct: 72, color: "bg-accent", textColor: "text-accent" },
          { name: "Dental Mat.", pct: 88, color: "bg-primary", textColor: "text-primary" },
          { name: "Prostho.", pct: 54, color: "bg-destructive", textColor: "text-destructive" },
        ].map((s) => (
          <div key={s.name} className="mb-2.5 flex items-center gap-3">
            <span className="w-20 flex-shrink-0 text-xs text-foreground">{s.name}</span>
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
              <div
                className={`h-full rounded-full ${s.color}`}
                style={{ width: `${s.pct}%` }}
              />
            </div>
            <span className={`w-8 text-right text-xs font-bold ${s.textColor}`}>
              {s.pct}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AnalyticsScreen;
