import { useState } from "react";

interface HomeScreenProps {
  onStartQuiz: () => void;
}

const quizzes = [
  {
    icon: "🏆",
    title: "NEET MDS Mock Test 1",
    badges: [
      { label: "MDS", color: "primary" },
      { label: "Hard", color: "destructive" },
    ],
    time: "10 min",
    questions: 12,
    participants: 248,
    variant: "accent" as const,
  },
  {
    icon: "🦷",
    title: "Oral Anatomy – Ch. 1",
    badges: [{ label: "BDS", color: "accent" }],
    time: "3 min",
    questions: 3,
    participants: 312,
    variant: "success" as const,
  },
  {
    icon: "🧪",
    title: "Dental Materials – Basics",
    badges: [{ label: "BDS", color: "accent" }],
    time: "2 min",
    questions: 2,
    participants: 189,
    variant: "primary" as const,
  },
];

const variantStyles = {
  accent: {
    card: "bg-accent/[0.08] border-accent/20",
    icon: "bg-accent/15",
  },
  success: {
    card: "bg-success/[0.08] border-success/20",
    icon: "bg-success/15",
  },
  primary: {
    card: "bg-primary/[0.08] border-primary/20",
    icon: "bg-primary/15",
  },
};

const badgeStyles: Record<string, string> = {
  primary: "bg-primary/15 text-primary",
  accent: "bg-accent/15 text-accent",
  destructive: "bg-destructive/15 text-destructive",
};

const HomeScreen = ({ onStartQuiz }: HomeScreenProps) => {
  const [activeCategory, setActiveCategory] = useState("All");

  return (
    <div className="flex-1 overflow-y-auto p-4">
      {/* Hero Card */}
      <div className="mb-4 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/25 to-accent/10 p-4">
        <h2 className="text-lg font-bold text-foreground">Hello, Sam 👋</h2>
        <p className="mt-1 text-xs text-muted-foreground">
          Ready to test your knowledge today?
        </p>
        <div className="mt-3 flex rounded-lg bg-background/30 p-3 text-center">
          <div className="flex-1">
            <div className="text-xl font-extrabold text-accent">3</div>
            <div className="text-[10px] text-muted-foreground">Tests Taken</div>
          </div>
          <div className="w-px bg-border" />
          <div className="flex-1">
            <div className="text-xl font-extrabold text-accent">78%</div>
            <div className="text-[10px] text-muted-foreground">Avg Score</div>
          </div>
          <div className="w-px bg-border" />
          <div className="flex-1">
            <div className="text-xl font-extrabold text-accent">#5</div>
            <div className="text-[10px] text-muted-foreground">Leaderboard</div>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="mb-4 flex gap-2">
        {["All", "BDS", "MDS"].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold border transition-colors ${
              activeCategory === cat
                ? "bg-primary/20 border-primary/50 text-primary"
                : "bg-secondary border-border text-muted-foreground"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Quiz Cards */}
      <div className="space-y-3">
        {quizzes.map((quiz) => (
          <button
            key={quiz.title}
            onClick={onStartQuiz}
            className={`w-full rounded-xl border p-4 text-left ${variantStyles[quiz.variant].card}`}
          >
            <div className="flex gap-3">
              <div
                className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg text-xl ${variantStyles[quiz.variant].icon}`}
              >
                {quiz.icon}
              </div>
              <div>
                <div className="text-sm font-bold text-foreground">
                  {quiz.title}
                </div>
                <div className="mt-1 flex gap-1.5">
                  {quiz.badges.map((b) => (
                    <span
                      key={b.label}
                      className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${badgeStyles[b.color]}`}
                    >
                      {b.label}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-3 flex gap-4 text-[10px] text-muted-foreground">
              <span>⏱ {quiz.time}</span>
              <span>❓ {quiz.questions} Qs</span>
              <span>👥 {quiz.participants}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default HomeScreen;
