import { useState } from "react";

interface LoginScreenProps {
  onLogin: (role: "student" | "admin") => void;
}

const LoginScreen = ({ onLogin }: LoginScreenProps) => {
  const [role, setRole] = useState<"student" | "admin">("student");

  return (
    <div className="flex min-h-screen flex-col bg-background px-6 py-8">
      {/* Logo */}
      <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent text-3xl">
        🦷
      </div>
      <h1 className="text-center text-xl font-bold text-foreground">
        Dr. Anchal's Classes
      </h1>
      <p className="mb-6 text-center text-sm text-muted-foreground">
        Master Dentistry. Ace Every Exam.
      </p>

      {/* Role Tabs */}
      <div className="mb-5 flex rounded-xl border border-border bg-secondary p-1">
        <button
          onClick={() => setRole("student")}
          className={`flex-1 rounded-lg py-2.5 text-sm font-medium transition-colors ${
            role === "student"
              ? "bg-muted text-foreground"
              : "text-muted-foreground"
          }`}
        >
          🎓 Student
        </button>
        <button
          onClick={() => setRole("admin")}
          className={`flex-1 rounded-lg py-2.5 text-sm font-medium transition-colors ${
            role === "admin"
              ? "bg-muted text-foreground"
              : "text-muted-foreground"
          }`}
        >
          ⚙️ Admin
        </button>
      </div>

      {/* Form */}
      <div className="space-y-3">
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-muted-foreground">
            Email Address
          </label>
          <input
            type="email"
            placeholder="student@example.com"
            className="w-full rounded-lg border border-border bg-muted px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-xs font-semibold text-muted-foreground">
            Password
          </label>
          <input
            type="password"
            placeholder="••••••••••"
            className="w-full rounded-lg border border-border bg-muted px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground"
          />
        </div>
      </div>

      {/* Sign In Button */}
      <button
        onClick={() => onLogin(role)}
        className="mt-5 w-full rounded-xl bg-gradient-to-r from-primary to-accent py-3.5 text-center text-sm font-bold text-primary-foreground"
      >
        Sign In as {role === "student" ? "Student" : "Admin"}
      </button>

      <button
        onClick={() => onLogin(role)}
        className="mt-2 text-center text-xs text-accent"
      >
        Use demo {role} credentials →
      </button>

      {/* Feature cards */}
      <div className="mt-8 flex gap-3">
        {[
          { icon: "📚", label: "500+\nQuestions" },
          { icon: "📊", label: "Live\nAnalytics" },
          { icon: "🏆", label: "Rank\nLeaderboard" },
        ].map((f) => (
          <div
            key={f.icon}
            className="flex flex-1 flex-col items-center rounded-lg border border-border bg-secondary p-3"
          >
            <span className="mb-1 text-xl">{f.icon}</span>
            <span className="whitespace-pre-line text-center text-[10px] leading-tight text-muted-foreground">
              {f.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LoginScreen;
