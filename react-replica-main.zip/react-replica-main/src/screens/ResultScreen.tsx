import { useState } from "react";

interface ResultScreenProps {
  onBack: () => void;
}

const ResultScreen = ({ onBack }: ResultScreenProps) => {
  const [tab, setTab] = useState<"overview" | "review">("overview");

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Tabs */}
      <div className="flex border-b border-border bg-secondary">
        <button
          onClick={() => setTab("overview")}
          className={`flex-1 py-3 text-center text-xs font-semibold ${
            tab === "overview"
              ? "border-b-2 border-accent text-accent"
              : "text-muted-foreground"
          }`}
        >
          📊 Overview
        </button>
        <button
          onClick={() => setTab("review")}
          className={`flex-1 py-3 text-center text-xs font-semibold ${
            tab === "review"
              ? "border-b-2 border-accent text-accent"
              : "text-muted-foreground"
          }`}
        >
          📋 Review
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {tab === "overview" ? <OverviewTab /> : <ReviewTab />}
      </div>

      {/* Back button */}
      <div className="p-4">
        <button
          onClick={onBack}
          className="w-full rounded-xl bg-gradient-to-r from-primary to-accent py-3 text-sm font-bold text-primary-foreground"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};

const OverviewTab = () => (
  <>
    {/* Score Ring */}
    <div className="mx-auto mb-4 flex h-28 w-28 flex-col items-center justify-center rounded-full border-2 border-success/30 bg-success/[0.06]">
      <div className="text-3xl font-black text-success">67%</div>
      <div className="text-xs text-muted-foreground">Good Job! 👍</div>
    </div>

    <div className="mb-4 text-center text-sm font-bold text-foreground">
      NEET MDS Mock Test 1
    </div>

    {/* Stats */}
    <div className="mb-4 flex gap-2.5">
      {[
        { val: "8", label: "Correct", color: "text-success" },
        { val: "3", label: "Wrong", color: "text-destructive" },
        { val: "1", label: "Skipped", color: "text-warning" },
      ].map((s) => (
        <div
          key={s.label}
          className="flex-1 rounded-lg border border-success/20 bg-muted p-3 text-center"
        >
          <div className={`text-xl font-extrabold ${s.color}`}>{s.val}</div>
          <div className="mt-1 text-[10px] text-muted-foreground">
            {s.label}
          </div>
        </div>
      ))}
    </div>

    {/* Breakdown */}
    <div className="rounded-xl border border-border bg-secondary p-4">
      <div className="mb-3 text-xs font-bold text-foreground">
        Score Breakdown
      </div>
      {[
        { label: "Score", value: "8 / 12" },
        { label: "Time Taken", value: "9m 2s" },
        { label: "Date", value: "2024-01-20" },
      ].map((row, i) => (
        <div
          key={row.label}
          className={`flex justify-between py-2 ${
            i < 2 ? "border-b border-border" : ""
          }`}
        >
          <span className="text-xs text-muted-foreground">{row.label}</span>
          <span className="text-xs font-semibold text-foreground">
            {row.value}
          </span>
        </div>
      ))}
    </div>
  </>
);

const reviewData = [
  {
    correct: true,
    question: "Q1. The permanent maxillary first molar has how many roots?",
    explanation:
      "The maxillary first molar has 3 roots: mesiobuccal, distobuccal, and palatal. The palatal root is the longest.",
  },
  {
    correct: false,
    question:
      "Q2. Which alloy is most commonly used for cast metal restorations?",
    explanation:
      "Gold alloys are the gold standard for cast metal restorations due to their biocompatibility and corrosion resistance.",
  },
  {
    correct: true,
    question: "Q3. The cusp of Carabelli is found on which tooth?",
    explanation: null,
  },
];

const ReviewTab = () => (
  <>
    <p className="mb-3 text-center text-xs text-muted-foreground">
      Tap any question for explanation
    </p>
    <div className="space-y-3">
      {reviewData.map((r, i) => (
        <div
          key={i}
          className={`rounded-lg border border-border bg-secondary p-3 ${
            r.correct ? "border-l-[3px] border-l-success" : "border-l-[3px] border-l-destructive"
          }`}
        >
          <span
            className={`inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
              r.correct
                ? "bg-success/15 text-success"
                : "bg-destructive/15 text-destructive"
            }`}
          >
            {r.correct ? "✓ Correct" : "✗ Wrong"}
          </span>
          <p className="mt-2 text-xs font-semibold leading-relaxed text-foreground">
            {r.question}
          </p>
          {r.explanation && (
            <div className="mt-2.5 rounded-md border border-accent/20 bg-accent/[0.06] p-3">
              <div className="mb-1 text-xs font-bold text-accent">
                💡 Explanation
              </div>
              <p className="text-xs leading-relaxed text-foreground">
                {r.explanation}
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  </>
);

export default ResultScreen;
