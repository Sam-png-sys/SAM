const podium = [
  { name: "Rahul", score: "88%", medal: "🥈", rank: 2, height: 60, color: "rgba(192,192,192,0.15)", borderColor: "rgba(192,192,192,0.6)", textColor: "#C0C0C0" },
  { name: "Arjun", score: "91%", medal: "🥇", rank: 1, height: 80, color: "rgba(255,215,0,0.15)", borderColor: "rgba(255,215,0,0.6)", textColor: "#FFD700" },
  { name: "Priya", score: "74%", medal: "🥉", rank: 3, height: 48, color: "rgba(205,127,50,0.15)", borderColor: "rgba(205,127,50,0.6)", textColor: "#CD7F32" },
];

const otherRanks = [
  { rank: 4, name: "Sneha Patel", score: "67%", isYou: false },
  { rank: 5, name: "Sam (You)", score: "62%", isYou: true },
  { rank: 6, name: "Kavya", score: "55%", isYou: false },
];

const LeaderboardScreen = () => {
  return (
    <div className="flex-1 overflow-y-auto">
      {/* Header */}
      <div className="border-b border-border bg-gradient-to-br from-primary/20 to-accent/[0.08] p-4 text-center">
        <h2 className="text-lg font-bold text-foreground">🏆 Leaderboard</h2>
        <p className="mt-1 text-xs text-muted-foreground">Top performers this month</p>
      </div>

      <div className="p-4">
        {/* Podium */}
        <div className="mb-4 flex items-end gap-3 px-2">
          {podium.map((p) => (
            <div key={p.name} className="flex flex-1 flex-col items-center">
              <span className="mb-1 text-2xl">🎓</span>
              <span className="text-xs font-bold text-foreground">{p.name}</span>
              <span className="text-[10px] text-muted-foreground">{p.score}</span>
              <span className="my-1 text-lg">{p.medal}</span>
              <div
                className="flex w-full items-center justify-center rounded-md border-t-2"
                style={{
                  height: p.height,
                  background: p.color,
                  borderColor: p.borderColor,
                }}
              >
                <span className="text-xl font-black" style={{ color: p.textColor }}>
                  {p.rank}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Rest of list */}
        <div className="overflow-hidden rounded-xl border border-border bg-secondary">
          {otherRanks.map((r, i) => (
            <div
              key={r.rank}
              className={`flex items-center gap-3 px-4 py-3 ${
                i < otherRanks.length - 1 ? "border-b border-border" : ""
              } ${r.isYou ? "bg-accent/[0.05]" : ""}`}
            >
              <span
                className={`text-sm font-bold ${
                  r.isYou ? "text-accent" : "text-muted-foreground"
                }`}
              >
                #{r.rank}
              </span>
              <span className="text-xl">🎓</span>
              <span
                className={`flex-1 text-sm font-semibold ${
                  r.isYou ? "text-accent" : "text-foreground"
                }`}
              >
                {r.name}
              </span>
              <span
                className={`text-sm font-extrabold ${
                  r.isYou ? "text-accent" : "text-foreground"
                }`}
              >
                {r.score}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LeaderboardScreen;
