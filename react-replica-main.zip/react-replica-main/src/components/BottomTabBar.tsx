interface Tab {
  icon: string;
  label: string;
  id: string;
}

interface BottomTabBarProps {
  tabs: Tab[];
  activeTab: string;
  onTabChange: (id: string) => void;
}

const BottomTabBar = ({ tabs, activeTab, onTabChange }: BottomTabBarProps) => {
  return (
    <div className="flex border-t border-border bg-secondary">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className="flex flex-1 flex-col items-center justify-center gap-1 py-3"
        >
          <span className="text-lg">{tab.icon}</span>
          <span
            className={`text-xs font-semibold ${
              activeTab === tab.id ? "text-accent" : "text-muted-foreground"
            }`}
          >
            {tab.label}
          </span>
        </button>
      ))}
    </div>
  );
};

export default BottomTabBar;
