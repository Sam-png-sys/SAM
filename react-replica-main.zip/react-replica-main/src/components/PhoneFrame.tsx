import { ReactNode } from "react";

interface PhoneFrameProps {
  children: ReactNode;
}

const PhoneFrame = ({ children }: PhoneFrameProps) => {
  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col bg-background">
      {children}
    </div>
  );
};

export default PhoneFrame;
