import { useState } from "react";
import PhoneFrame from "@/components/PhoneFrame";
import BottomTabBar from "@/components/BottomTabBar";
import LoginScreen from "@/screens/LoginScreen";
import HomeScreen from "@/screens/HomeScreen";
import QuizScreen from "@/screens/QuizScreen";
import ResultScreen from "@/screens/ResultScreen";
import AnalyticsScreen from "@/screens/AnalyticsScreen";
import LeaderboardScreen from "@/screens/LeaderboardScreen";
import AdminScreen from "@/screens/AdminScreen";

type Screen = "login" | "home" | "quiz" | "result" | "analytics" | "leaderboard" | "admin";

const studentTabs = [
  { id: "home", icon: "🏠", label: "Home" },
  { id: "analytics", icon: "📊", label: "Analytics" },
  { id: "leaderboard", icon: "🏆", label: "Ranks" },
];

const Index = () => {
  const [screen, setScreen] = useState<Screen>("login");
  const [activeTab, setActiveTab] = useState("home");

  const handleLogin = (role: "student" | "admin") => {
    if (role === "admin") {
      setScreen("admin");
    } else {
      setScreen("home");
      setActiveTab("home");
    }
  };

  const handleTabChange = (id: string) => {
    setActiveTab(id);
    setScreen(id as Screen);
  };

  if (screen === "login") {
    return (
      <PhoneFrame>
        <LoginScreen onLogin={handleLogin} />
      </PhoneFrame>
    );
  }

  if (screen === "admin") {
    return (
      <PhoneFrame>
        <AdminScreen />
      </PhoneFrame>
    );
  }

  if (screen === "quiz") {
    return (
      <PhoneFrame>
        <QuizScreen
          onFinish={() => setScreen("result")}
          onQuit={() => {
            setScreen("home");
            setActiveTab("home");
          }}
        />
      </PhoneFrame>
    );
  }

  if (screen === "result") {
    return (
      <PhoneFrame>
        <ResultScreen
          onBack={() => {
            setScreen("home");
            setActiveTab("home");
          }}
        />
      </PhoneFrame>
    );
  }

  return (
    <PhoneFrame>
      <div className="flex flex-1 flex-col overflow-hidden">
        {activeTab === "home" && <HomeScreen onStartQuiz={() => setScreen("quiz")} />}
        {activeTab === "analytics" && <AnalyticsScreen />}
        {activeTab === "leaderboard" && <LeaderboardScreen />}
      </div>
      <BottomTabBar tabs={studentTabs} activeTab={activeTab} onTabChange={handleTabChange} />
    </PhoneFrame>
  );
};

export default Index;
